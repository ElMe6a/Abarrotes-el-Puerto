## Module <sales_credit_limit>

#### 18.09.2021
#### Version 15.0.1.0.0
##### ADD
- Initial commit for Customer Credit Limit with Due Amount Warning
